function valueSet(){
	//initialize object
	let user = {};
		user.item = ['coin', 'button', 'feather', 'marble', 'knife'];
		user.dateName = document.getElementById('dateName').value;
		user.animal = document.getElementById('animal').value;
		user.foodType = document.getElementById('foodType').value;
	//enter the game
	tellStory(user);
};

function tellStory(user){
	let choices = [];
	let item = user.item[Math.round(Math.random() * ((user.item).length-1))];
	
	console.log('So after you recovered your lucky ' + item + '\nyou decide to take ' + user.dateName + ' out to ');
	//loop for valid input
	while (choices[0] !== 'dinner' && choices[0] !== 'movie'){
		choices[0] = prompt('dinner or movie?');
	}
	//(A)
	if (choices[0] === 'dinner'){
		console.log('dinner. And ' + user.dateName + ' insists on having ');
		//loop for valid input
		while (choices[1] !== 'pizza' && choices[1] !== user.foodType){
			choices[1] = prompt('pizza or ' + user.foodType + '?');
		}
		console.log(choices[1] + '. So you get to the ' + choices[1] + ' joint and opt for ');
		
		//(A1)
		if (choices[1] === 'pizza'){
			//loop for valid input
			while (choices[2] !== 'plain' && choices[2] !== 'special'){
				choices[2] = prompt('plain or special?');
			}
			console.log('the ' + choices[2] + ' ' + choices[1] +'.');
			
			//(A1a)
			if(choices[2] === 'plain'){
				console.log(user.dateName + ' is totally bored and thinks you are lame.');
			
			}else{//(A1b)
				console.log('The meat looks strange so you ask the waiter about it.\nHe tells you that it\'s ' + user.animal + '. ' + user.dateName + ' is impressed by \nyour sense of adventure and hopes to see you again!');
			}
		
		}else{//(A2)
			console.log('the spicy ' + user.animal + '.');
			//do not loop, use default if input does not specifically indicate "yes" "YES" "y" or "Y"
			choices[2] = prompt('Do you have desert?');
			console.log('You and '+ user.dateName + ' enjoy the meal,');
			
			//(A2a)
			if(choices[2] === 'yes' || choices[2] === 'YES'|| choices[2] === 'y'|| choices[2] === 'Y'){
				console.log('but ' + user.dateName + ' fat-shames you for eating too much cake.');
			
			}else{//(A2b)
				console.log('and ' + user.dateName + ' compliments you on your self-restraint\nafter you turn down the desert cart.');
			}
		}
	
	}else{//(B)
		console.log('a movie.');
		//loop for valid input
		while (choices[1] !== 'horror' && choices[1] !== 'comedy'){
			choices[1] = prompt('comedy or horror?');
		}
		console.log('You decide to watch');
		
		//(B1)
		if (choices[1] === 'horror'){
			console.log('\"Attack of the Killer ' + user.animal + 's.\" You can tell\n' + user.dateName + ' is frightened so you decide to ');
			//loop for valid input
			while (choices[2] !== 'scare' && choices[2] !== 'comfort'){
				choices[2] = prompt('scare or comfort?');
			}
			console.log(choices[2] + ' ' + user.dateName);
			
			//(B1a)
			if(choices[2] === 'scare'){
				console.log('even more.\n' + user.dateName + ' calls you a jerk and storms out of the theatre!');
			
			}else{//(B1b)
				console.log('The two of you hold hands for the rest of the date.');
			}
		
		}else{//(B2)
			console.log('\"Legend of the ' + user.foodType + ' Caserole.\" The movie has you laughing so hard \n that you feel like you may wet yourself.');
			//loop for valid input
			while (choices[2] !== 'hold it' && choices[2] !== 'restroom'){
				choices[2] = prompt('hold it or restroom?');
			}
			
			//(B2a)
			if(choices[2] === 'restroom'){
				console.log('You run out to use the restroom, but when you get\nback your date has mysteriously vanished! You notice\nthat your lucky ' + item + ' is also missing....');
			
			}else{//(B2b)
				console.log('You try to hold your bladder and fail. ' + user.dateName + ' Notices\nand starts laughing even harder...\n' + user.dateName + ' ends up having an accident as well and you both\ncan\'t stop laughing for the rest of the night.');
			}
		}
	}
};
