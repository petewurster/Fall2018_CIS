'use strict'

//run script after loaded
$(()=> {



















//end of pageload func 
});