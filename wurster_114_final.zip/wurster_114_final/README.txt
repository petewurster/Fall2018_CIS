1-Drop your index.html and any necessary files (images, etc) into this folder.
2-Copy these lines into your <head> to use the editor:

	<script src="./$()-.js"></script>
	<script src="./final.js"></script>

3-Results will print valid css into the browser which can be copied to an external stylesheet.
4-Remove the script tags from your project before publishing your page.