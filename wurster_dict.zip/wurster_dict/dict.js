'use strict'
let lastPick = {};
	lastPick.className = 'term';

let terms = [
	{'API' : 'abbreviation for Application Programming Interface: a way of communicating with a particular computer program or internet service'},
	{'browser' : 'a computer program that makes it possible for you to read information on the internet'},
	{'email' : 'the system for using computers to send messages over the internet'},
	{'Spam' : 'trademark[ed] brand name for a type of meat sold in metal containers, made mostly from pork'},
	{'DHCP' : 'abbreviation for Dynamic Host Configuration Protocol: a method that gives a new IP address to a computer each time it joins a network'},
]

//run script after page is loaded
document.addEventListener("DOMContentLoaded", ()=> {

	//create random colors
	function makeColor() {
		let rgb = 'rgb(';
		for(let x = 0; x < 3; x ++){
			rgb += Math.floor(Math.random() * 256);
			if(x !== 2) {
				rgb += ', ';
			}
		}
		return rgb + ')';
	}

	//handle clicks
	function showDef(term) {
		let newColor = makeColor();
		//reset last clicked item
		lastPick.className = 'term';
		lastPick.style = '';
		//add class to selected term
		term.target.className += ' selected';
		term.target.style.backgroundColor = newColor;
		//define new last click
		lastPick = term.target;
		//set h2 by isolating clicked id & associate with the terms array
		let id = (term.target.id).slice(2);
		let h2 = document.getElementById('h2');
		h2.textContent = terms[id][term.target.textContent];
		h2.style.backgroundColor = newColor;
	}

	//handle new entries
	function setDef(boxWord) {
		//make new nodes and append to list
		let newWord = document.createElement('li');
			newWord.className = 'term';
			newWord.id = 'li' + terms.length;
			let newWordText = document.createTextNode(boxWord.target.value);
			newWord.appendChild(newWordText);
		let list = document.getElementsByTagName('ul')[0];
			list.insertBefore(newWord, list.lastChild);
		//use placeholder until I can figure out how to use an API to auto-update the new definition
		let newDefText = '\'s definition will eventually be completed via fetch() interaction w/a REAL online dictionary'; 
		//update array with new term object
		terms.push({[newWord.textContent] : newWord.textContent + newDefText});
		//enable clicking for new terms
		newWord.addEventListener('click', showDef);
		let box = document.getElementById('newDef');
		box.value = '';
	}

	//build list from array
	for(let item = 0; item<terms.length; item ++) {
		let text = Object.keys(terms[item]);
		let lixText = document.createTextNode(text);
		let lix = document.createElement('li');
			lix.appendChild(lixText);
			lix.className = 'term';
			lix.id = 'li' + item;
		let list = document.getElementsByTagName('ul')[0];
			list.appendChild(lix);
	}

	//paint listeners onto terms array
	let list = document.getElementsByTagName('li');
	for(let item of list) {
		item.addEventListener('click', showDef);
	}

	//add input box to list
	let box = document.createElement('input');
		box.type = 'text';
		box.id = 'newDef';
		box.placeholder = ' type a new word here'
	document.getElementsByTagName('ul')[0].appendChild(box);
	//add listener to input box
	let newDef = document.getElementById('newDef');
		newDef.addEventListener('change', setDef);


//end of pageloading function 
});