'use strict';

$(function() {
    let request = $.ajax({
        method: 'GET',
        url: 'people.json',
        dataType: 'json',
    });

    request.done(function(data) {
        let list = data.body.list;
        let resultBox = $('#result-box');
        let unorderedList = $('<ul>');
        resultBox.append(unorderedList);

        for (let person of list) {
            let listItem = $('<li>');
            listItem.text(person.name);
            listItem.attr('data-url', person.links[0].href);
            unorderedList.append(listItem);
        }

        list = $('li');
        list.on('click', function(e) {
            let subReq = $.ajax(this.dataset.url);
            subReq.done((subData)=> {
                $('#loaded-data').text((subData.body.art[0].location.description));
            });
            subReq.fail((response)=> {
                console.log('ERROR:' + response.statusText);
            });
        });

    });

    request.fail(function(response) {
        console.log('ERROR:' + response.statusText);
    });







});
